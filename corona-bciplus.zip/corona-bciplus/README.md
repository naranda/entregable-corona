# Información del proyecto Corona - BCI Plus
___________________
___________________
### Resumen
API Rest pública para registrar las ventas realizadas en campaña CORONA - BCI Plus.

### Stack Tecnológico
- Java 11
- Spring Boot 2.7.5
- MongoDB 6.0.2 Community
- Maven 3.8.6

### Microservicio CORONA - BCI Plus.

A continuación se indican los pasos para verificación de servicio en ambiente local usando Docker.

### Compilar y generar package

``$ mvn clean package -DskipTests``

### Generación contenedor Docker

``$ docker build --no-cache --build-arg JAR_FILE=./target/corona-bciplus-1.0.jar -t corona-bciplus:latest .``


### Ejecutar Docker

``$ docker run -p 8080:8080 corona-bciplus``

### Comprobación Local

``http://localhost:8080/corona-bciplus/api/swagger-ui.html``

### Servicios Rest


#### 1 Registro de venta realizada en campaña CORONA - BCI Plus

    URI: http://localhost:8080/corona-bciplus/api/sales/

    Tipo: POST

    JSON:

    {
	    "campaign": "6241d686423a11001cbbc133",
	    "code": "056G-JY59-2DCDH1",
	    "sale": {
		    "orderNumber": "Pedido R367790352 | Corona",
		    "subtotal": 3199,
		    "items": [{
			    "title": "Polera mujer",
			    "quantity": 1,
			    "totalPrice": 3199
		    }],
		    "successUrl": "https://www.corona.cl/orders/R367790352"
	    }
    }

**NOTA**: 
- Estructura de JSON puede cambiar, depende de definición script JS de consumo de API y Ecommerce.
- Servicio soporta cualquier estructura en formato JSON.


#### 2 Registro log de errores

    URI: http://localhost:8080/corona-bciplus/api/log/

    Tipo: Post

    JSON:

    {
        "store": "www.corona.cl",
        "leadCode": "HDU-PDF-XLS",
        "message": "Error en procesar la venta de polera de mujer",
        "error": "error venta"
    }

**NOTA**:
- Estructura de JSON puede cambiar, depende de definición script JS de consumo de API y Ecommerce.
- Servicio soporta cualquier estructura en formato JSON