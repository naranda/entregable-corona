package cl.corona.bciplus.infrastructure.api;

import cl.corona.bciplus.application.inbound.SaleInboundPort;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/sales")
@Tag(name = "Ventas", description = "Apis de registro de ventas de campaña CORONA Bci Plus")
@Slf4j
public class SaleController {

    @Autowired
    private SaleInboundPort saleInboundPort;

    @Operation(summary = "Registro de venta realizada en campaña CORONA - BCI Plus")
    @PostMapping("/")
    public ResponseEntity<Void> saveSale(@RequestBody Map saleRequest) {
        saleInboundPort.saveSale(saleRequest);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
