package cl.corona.bciplus.application.inbound;

import java.util.Map;

public interface LogErrorInboundPort {

    void saveLog(Map request);
}
