package cl.corona.bciplus.infrastructure.db.repository;

import cl.corona.bciplus.application.outbound.LogErrorOutboundPort;
import cl.corona.bciplus.infrastructure.db.entity.LogError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class LogErrorRepository implements LogErrorOutboundPort {

    @Autowired
    private MongoDBLogErrorRepository mongoDBLogErrorRepository;

    @Override
    public void saveLog(LogError logError) {
        mongoDBLogErrorRepository.save(logError);
        log.debug("Log con error guardado");
    }

}
