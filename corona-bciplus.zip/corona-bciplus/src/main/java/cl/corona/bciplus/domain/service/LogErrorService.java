package cl.corona.bciplus.domain.service;

import cl.corona.bciplus.application.inbound.LogErrorInboundPort;
import cl.corona.bciplus.application.outbound.LogErrorOutboundPort;
import cl.corona.bciplus.domain.ex.BadRequestException;
import cl.corona.bciplus.infrastructure.db.entity.LogError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;

@Service
@Slf4j
public class LogErrorService implements LogErrorInboundPort {

    @Autowired
    private LogErrorOutboundPort logErrorOutboundPort;

    @Override
    public void saveLog(Map request) {

        if(request == null || request.isEmpty()){
            log.error("Falta el cuerpo en formato JSON");
            throw new BadRequestException("Falta el cuerpo en formato JSON ");
        }
        log.debug("registro de log de errores");
        log.debug("Json Request: {}", request);

        LogError logError = new LogError();
        logError.setBody(request);
        logError.setRegisterDate(LocalDateTime.now());

        logErrorOutboundPort.saveLog(logError);
    }
}
