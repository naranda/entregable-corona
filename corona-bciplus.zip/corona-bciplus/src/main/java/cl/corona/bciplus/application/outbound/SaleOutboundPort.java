package cl.corona.bciplus.application.outbound;

import cl.corona.bciplus.infrastructure.db.entity.Sale;

public interface SaleOutboundPort {

    void saveSale(Sale saleRequest);
}
