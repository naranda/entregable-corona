package cl.corona.bciplus.infrastructure.db.repository;

import cl.corona.bciplus.application.outbound.SaleOutboundPort;
import cl.corona.bciplus.infrastructure.db.entity.Sale;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class SaleRepository implements SaleOutboundPort {

    @Autowired
    private MongoDBSaleRepository mongoDBSaleRepository;

    @Override
    public void saveSale(Sale sale) {
        log.debug("Venta a guardar: {}", sale);

        mongoDBSaleRepository.save(sale);
        log.debug("Venta MAP guardada");
    }

}
