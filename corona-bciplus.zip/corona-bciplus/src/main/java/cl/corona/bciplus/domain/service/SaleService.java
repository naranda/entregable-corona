package cl.corona.bciplus.domain.service;


import cl.corona.bciplus.application.inbound.SaleInboundPort;
import cl.corona.bciplus.application.outbound.SaleOutboundPort;
import cl.corona.bciplus.domain.ex.BadRequestException;
import cl.corona.bciplus.infrastructure.db.entity.Sale;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;

@Service
@Slf4j
public class SaleService implements SaleInboundPort {

    @Autowired
    private SaleOutboundPort saleOutboundPort;

    @Override
    public void saveSale(Map saleRequest) {

        if (saleRequest == null || saleRequest.isEmpty()) {
            log.error("Falta el cuerpo en formato JSON");
            throw new BadRequestException("Falta el cuerpo en formato JSON ");
        }

        log.debug("Preparando venta a guardar");
        log.debug("Request: {}", saleRequest);

        LocalDateTime now = LocalDateTime.now();

        Sale sale = new Sale();
        sale.setBody(saleRequest);
        sale.setRegisterDate(now);

        saleOutboundPort.saveSale(sale);
    }

}
