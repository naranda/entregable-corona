package cl.corona.bciplus.infrastructure.db.repository;

import cl.corona.bciplus.infrastructure.db.entity.Sale;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MongoDBSaleRepository extends MongoRepository<Sale, String> {

}
