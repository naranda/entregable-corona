package cl.corona.bciplus.application.outbound;

import cl.corona.bciplus.infrastructure.db.entity.LogError;

public interface LogErrorOutboundPort {
    void saveLog(LogError logRequest);
}
