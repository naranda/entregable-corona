package cl.corona.bciplus.application.inbound;

import java.util.Map;

public interface SaleInboundPort {

    void saveSale(Map saleRequest);

}
