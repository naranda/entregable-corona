package cl.corona.bciplus.domain.service;

import cl.corona.bciplus.application.outbound.LogErrorOutboundPort;
import cl.corona.bciplus.domain.ex.BadRequestException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

@ExtendWith(MockitoExtension.class)
class LogErrorServiceTest {

    @Mock
    private LogErrorOutboundPort logErrorOutboundPort;

    @InjectMocks
    private LogErrorService logErrorService;

    @Test
    void saveLogErrorOkTest() throws JsonProcessingException {
        Map<Object, Object> map = requestBody();
        logErrorService.saveLog(map);
    }

    @Test
    void saveLogErrorTest() {
        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> logErrorService.saveLog(null))
                .withNoCause();
    }

    private Map<Object, Object> requestBody() throws JsonProcessingException {
        String body = "{\"error\":\"Error\",\"code\":\"056G-JY59-2DCDH1\"}";

        ObjectMapper mapper = new ObjectMapper();
        Map<Object, Object> map = mapper.readValue(body, Map.class);

        return map;
    }

}
