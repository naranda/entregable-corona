package cl.corona.bciplus.infrastructure.api;

import cl.corona.bciplus.application.inbound.SaleInboundPort;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Map;

import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(SaleController.class)
class SaleControllerTest {

    @MockBean
    private SaleInboundPort saleInboundPort;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void saveSaleTest_status200() throws Exception {

        String body = requestBody();

        ObjectMapper mapper = new ObjectMapper();
        Map<Object, Object> map = mapper.readValue(body, Map.class);

        doNothing().when(saleInboundPort).saveSale(map);

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sales/")
                        .content(body)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void saveSaleErrorTest_status400() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sales/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    private String requestBody() {
        String body = "{\"campaign\":\"6241d686423a11001cbbc133\",\"code\":\"056G-JY59-2DCDH1\",\"sale\":{\"orderNumber\":\"Pedido R367790352 | CORONA\",\"subtotal\":3199,\"items\":[{\"title\":\"Polera mujer\",\"quantity\":1,\"totalPrice\":3199}],\"successUrl\":\"https://www.corona.cl/orders/R367790352\"}}";

        return body;
    }

}
