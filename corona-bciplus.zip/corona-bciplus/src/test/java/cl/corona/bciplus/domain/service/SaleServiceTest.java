package cl.corona.bciplus.domain.service;

import cl.corona.bciplus.application.outbound.SaleOutboundPort;
import cl.corona.bciplus.domain.ex.BadRequestException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

@ExtendWith(MockitoExtension.class)
class SaleServiceTest {

    @Mock
    private SaleOutboundPort saleOutboundPort;

    @InjectMocks
    private SaleService saleService;

    @Test
    void saveSaleOkTest() throws JsonProcessingException {
        Map<Object, Object> map = requestBody();
        saleService.saveSale(map);
    }

    @Test
    void saveSaleErrorTest() {

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.saveSale(null))
                .withNoCause();
    }

    private Map<Object, Object> requestBody() throws JsonProcessingException {
        String body = "{\"campaign\":\"6241d686423a11001cbbc133\",\"code\":\"056G-JY59-2DCDH1\",\"sale\":{\"orderNumber\":\"Pedido R367790352 | CORONA\",\"subtotal\":3199,\"items\":[{\"title\":\"Polera mujer\",\"quantity\":1,\"totalPrice\":3199}],\"successUrl\":\"https://www.corona.cl/orders/R367790352\"}}";

        ObjectMapper mapper = new ObjectMapper();
        Map<Object, Object> map = mapper.readValue(body, Map.class);

        return map;
    }
}
