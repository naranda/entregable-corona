package cl.corona.bciplus.infrastructure.api;

import cl.corona.bciplus.application.inbound.LogErrorInboundPort;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Map;

import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(LogErrorController.class)
public class LogErrorControllerTest {

    @MockBean
    private LogErrorInboundPort logErrorInboundPort;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void saveLogErrorTest_status200() throws Exception {
        String body = requestBody();

        ObjectMapper mapper = new ObjectMapper();
        Map<Object, Object> map = mapper.readValue(body, Map.class);

        doNothing().when(logErrorInboundPort).saveLog(map);

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/log/")
                        .content(body)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void saveLogErrorTest_status400() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/log/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    private String requestBody() {
        String body = "{\"store\":\"www.corona.cl\",\"leadCode\":\"056G-JY59-2DCDH1\",\"error\":\"Error venta\",\"message\":\"Error en venta\"}";

        return body;
    }
}
