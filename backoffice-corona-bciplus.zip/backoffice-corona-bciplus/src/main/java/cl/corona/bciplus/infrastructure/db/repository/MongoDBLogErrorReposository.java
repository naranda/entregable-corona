package cl.corona.bciplus.infrastructure.db.repository;

import cl.corona.bciplus.infrastructure.db.entity.LogError;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface MongoDBLogErrorReposository extends MongoRepository<LogError, String> {

    Page<LogError> findByRegisterDateBetween(LocalDate from, LocalDate to, Pageable pageable);

    List<LogError> findByRegisterDateBetween(LocalDate from, LocalDate to);
}
