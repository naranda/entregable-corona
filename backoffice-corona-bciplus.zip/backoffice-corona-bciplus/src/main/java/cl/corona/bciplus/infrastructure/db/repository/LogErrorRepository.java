package cl.corona.bciplus.infrastructure.db.repository;

import cl.corona.bciplus.application.outbound.LogErrorOutboundPort;
import cl.corona.bciplus.infrastructure.db.entity.LogError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
@Slf4j
public class LogErrorRepository implements LogErrorOutboundPort {

    @Autowired
    private MongoDBLogErrorReposository mongoDBLogErrorReposository;

    @Override
    public List<LogError> exportLogError(LocalDate from, LocalDate to) {
        return mongoDBLogErrorReposository.findByRegisterDateBetween(from, to);
    }

    @Override
    public Page<LogError> getLogErrors(int page, int size, LocalDate from, LocalDate to) {
        Pageable pageable = PageRequest.of(page, size);

        return mongoDBLogErrorReposository.findByRegisterDateBetween(from, to, pageable);
    }
}
