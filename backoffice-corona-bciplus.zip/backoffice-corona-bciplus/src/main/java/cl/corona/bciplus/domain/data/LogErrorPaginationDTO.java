package cl.corona.bciplus.domain.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogErrorPaginationDTO {
    private long totalPages;
    private long actualPage;
    private long totalElements;
    private List<LogErrorResponseDTO> logErrors;

}
