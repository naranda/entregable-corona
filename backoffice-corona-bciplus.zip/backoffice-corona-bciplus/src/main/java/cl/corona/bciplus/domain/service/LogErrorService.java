package cl.corona.bciplus.domain.service;

import cl.corona.bciplus.application.inbound.LogErrorInboundPort;
import cl.corona.bciplus.application.outbound.LogErrorOutboundPort;
import cl.corona.bciplus.domain.data.LogErrorPaginationDTO;
import cl.corona.bciplus.domain.data.LogErrorResponseDTO;
import cl.corona.bciplus.domain.ex.BadRequestException;
import cl.corona.bciplus.domain.ex.NoContentException;
import cl.corona.bciplus.domain.util.DateValidation;
import cl.corona.bciplus.infrastructure.db.entity.LogError;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
@Slf4j
public class LogErrorService implements LogErrorInboundPort {

    private static final String SHEET = "Errores";

    private static final String[] COLUMN_HEADERS = {"Comercio", "Lead code", "Fecha de registro", "Error", "Mensaje de error",};
    @Autowired
    private LogErrorOutboundPort logErrorOutboundPort;

    @Autowired
    private DateValidation dateValidation;
    private static final long PLUS_DAY = 1;

    @Override
    public ByteArrayInputStream exportLogError(LocalDate from, LocalDate to) {
        dateValidation.dateValidate(from, to);

        to = to.plusDays(PLUS_DAY);
        List<LogError> logErrors = logErrorOutboundPort.exportLogError(from, to);

        if (logErrors == null || logErrors.isEmpty()) {
            log.error("No existen registros para la fecha indicada");
            throw new NoContentException();
        }

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet(SHEET);

            CellStyle cellStyle = workbook.createCellStyle();
            Font font = workbook.createFont();

            // Header
            Row headerRow = sheet.createRow(0);
            for (int col = 0; col < COLUMN_HEADERS.length; col++) {
                Cell cell = headerRow.createCell(col);
                cellStyle.setAlignment(HorizontalAlignment.CENTER);
                cell.setCellStyle(cellStyle);
                font.setBold(true);
                cellStyle.setFont(font);
                cell.setCellValue(COLUMN_HEADERS[col]);

            }
            AtomicInteger rowIdx = new AtomicInteger(1);


            logErrors.stream().forEach(l -> {
                Map mapBody = l.getBody();
                ObjectMapper mapper = new ObjectMapper();
                LogErrorResponseDTO response = mapper.convertValue(mapBody, LogErrorResponseDTO.class);

                Row row = sheet.createRow(rowIdx.getAndIncrement());
                row.createCell(0).setCellValue(response.getStore());
                row.createCell(1).setCellValue(response.getLeadCode());
                LocalDateTime registerDate = l.getRegisterDate();
                String formatDate = registerDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
                row.createCell(2).setCellValue(formatDate);
                row.createCell(3).setCellValue(response.getError());
                row.createCell(4).setCellValue(response.getMessage());
            });

            autoSizeColumn(sheet);
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("Se produjo un error al generar archivo a exportar {}", e.getMessage());
            throw new BadRequestException("Se produjo un error al generar archivo a exportar");
        }
    }

    @Override
    public LogErrorPaginationDTO getLogErrors(int page, int size, LocalDate from, LocalDate to) {
        if (size <= 0) {
            throw new BadRequestException("Cantidad de items debe ser mayor o igual a 1");
        }
        if (page < 0) {
            log.error("Error con numero de pagina");
            throw new BadRequestException("Numero de página debe ser mayor o igual a 0");
        }
        dateValidation.dateValidate(from, to);
        to = to.plusDays(PLUS_DAY);
        Page<LogError> body = logErrorOutboundPort.getLogErrors(page, size, from, to);
        log.debug("Cantidad de registros: {}", body.getTotalElements());

        LogErrorPaginationDTO logErrorPaginationDTO = new LogErrorPaginationDTO();
        logErrorPaginationDTO.setActualPage(body.getNumber());
        logErrorPaginationDTO.setTotalElements(body.getTotalElements());
        logErrorPaginationDTO.setTotalPages(body.getTotalPages());
        logErrorPaginationDTO.setLogErrors(body.stream().map(b -> {
            Map mapBody = b.getBody();

            ObjectMapper mapper = new ObjectMapper();
            LogErrorResponseDTO response = null;
            try {
                response = mapper.convertValue(mapBody, LogErrorResponseDTO.class);

            } catch (Exception e) {
                log.error("Se produjo un error al mapear resultado de log de errores: {} ", e.getMessage());
            }

            response.setRegisterDate(b.getRegisterDate());

            return response;
        }).collect(Collectors.toList()));

        return logErrorPaginationDTO;
    }

    private void autoSizeColumn(Sheet sheet) {
        for (int col = 0; col < COLUMN_HEADERS.length; col++) {
            sheet.autoSizeColumn(col);
        }
    }
}
