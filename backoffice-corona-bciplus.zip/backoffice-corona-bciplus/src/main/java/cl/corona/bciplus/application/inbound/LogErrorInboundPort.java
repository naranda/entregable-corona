package cl.corona.bciplus.application.inbound;

import cl.corona.bciplus.domain.data.LogErrorPaginationDTO;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;

public interface LogErrorInboundPort {

    ByteArrayInputStream exportLogError(LocalDate from, LocalDate to);

    LogErrorPaginationDTO getLogErrors(int page, int size, LocalDate from, LocalDate to);
}
