package cl.corona.bciplus.infrastructure.api;

import cl.corona.bciplus.application.inbound.SaleInboundPort;
import cl.corona.bciplus.domain.data.SalePaginationDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequiredArgsConstructor
@RequestMapping("/sales")
@Tag(name = "Ventas", description = "Apis para reporteria de transacciones de campaña CORONA BCI Plus")
@Slf4j
public class SaleController {

    @Autowired
    private SaleInboundPort saleInboundPort;

    @Operation(summary = "Listar ventas realizadas de un rango de fechas")
    @GetMapping("")
    public ResponseEntity<SalePaginationDTO> getSales(@Parameter(description = "Número de página a mostrar") @RequestParam(name = "page", required = false, defaultValue = "0") int page,
                                                      @Parameter(description = "Cantidad de elementos por página") @RequestParam(name = "size", required = false, defaultValue = "10") int size,
                                                      @Parameter(description = "Rango de fecha desde, formato dd-MM-yyyy") @RequestParam(name = "from", required = true) @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate from,
                                                      @Parameter(description = "Rango de fecha hasta, formato dd-MM-yyyy") @RequestParam(name = "to", required = true) @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate to) {

        log.debug("Fecha desde: {}", from);
        log.debug("Fecha hasta: {}", to);

        return new ResponseEntity<>(saleInboundPort.getSales(page, size, from, to), HttpStatus.OK);

    }

    @Operation(summary = "Exportar ventas realizadas de un rango de fechas")
    @GetMapping("/export")
    public ResponseEntity<Resource> exportSales(
            @Parameter(description = "Rango de fecha desde, formato dd-MM-yyyy") @RequestParam(name = "from", required = true) @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate from,
            @Parameter(description = "Rango de fecha hasta, formato dd-MM-yyyy") @RequestParam(name = "to", required = true) @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate to) {

        log.debug("Fecha desde: {}", from);
        log.debug("Fecha hasta: {}", to);
        LocalDateTime ldt = LocalDateTime.now();
        String dateFormat = ldt.format(DateTimeFormatter.ofPattern("dd-MM-yyyy_HH:mm:ss"));

        String filename = "reporte_ventas_".concat(dateFormat).concat(".xlsx");
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(new InputStreamResource(saleInboundPort.exportSales(from, to)));

    }
}
