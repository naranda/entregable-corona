package cl.corona.bciplus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackofficeCoronaBciplusApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackofficeCoronaBciplusApplication.class, args);
    }

}
