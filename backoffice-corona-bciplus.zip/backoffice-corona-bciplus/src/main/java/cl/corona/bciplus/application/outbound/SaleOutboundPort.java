package cl.corona.bciplus.application.outbound;

import cl.corona.bciplus.infrastructure.db.entity.Sale;
import org.springframework.data.domain.Page;

import java.time.LocalDate;
import java.util.List;

public interface SaleOutboundPort {
    Page<Sale> getSales(int page, int size, LocalDate from, LocalDate to);

    List<Sale> exportSales(LocalDate from, LocalDate to);
}
