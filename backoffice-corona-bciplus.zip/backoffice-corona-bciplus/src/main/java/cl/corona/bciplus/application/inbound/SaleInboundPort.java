package cl.corona.bciplus.application.inbound;

import cl.corona.bciplus.domain.data.SalePaginationDTO;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;

public interface SaleInboundPort {
    SalePaginationDTO getSales(int page, int size, LocalDate from, LocalDate to);

    ByteArrayInputStream exportSales(LocalDate from, LocalDate to);
}
