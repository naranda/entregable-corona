package cl.corona.bciplus.domain.util;

import cl.corona.bciplus.domain.ex.BadRequestException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@Slf4j
public class DateValidation {

    public void dateValidate(LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            throw new BadRequestException("Falta ingresar rangos de fechas");
        }

        LocalDate now = LocalDate.now();

        if (from.isAfter(now)) {
            log.error("Fecha desde no puede ser mayor a fecha actual");
            throw new BadRequestException("Fecha desde no puede ser mayor a fecha actual");
        }

        if (to.isAfter(now)) {
            log.error("Fecha hasta no puede ser mayor a fecha actual");
            throw new BadRequestException("Fecha hasta no puede ser mayor a fecha actual");
        }

        if (from.isAfter(to)) {
            log.error("Fecha desde no puede ser mayor a fecha hasta");
            throw new BadRequestException("Fecha desde no puede ser mayor a fecha hasta");
        }
    }
}
