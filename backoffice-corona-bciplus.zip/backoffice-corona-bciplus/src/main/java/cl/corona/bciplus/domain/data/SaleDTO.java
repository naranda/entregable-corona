package cl.corona.bciplus.domain.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaleDTO {
    private String orderNumber;
    private List<ItemDTO> items;
    private int subtotal;
    private int comission;
    private String successUrl;

}
