package cl.corona.bciplus.infrastructure.db.repository;

import cl.corona.bciplus.application.outbound.SaleOutboundPort;
import cl.corona.bciplus.infrastructure.db.entity.Sale;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
@Slf4j
public class SaleRepository implements SaleOutboundPort {

    @Autowired
    private MongoDBSaleReposository mongoDBSaleReposository;


    @Override
    public Page<Sale> getSales(int page, int size, LocalDate from, LocalDate to) {

        Pageable pageable = PageRequest.of(page, size);

        return mongoDBSaleReposository.findByRegisterDateBetween(from, to, pageable);
    }


    @Override
    public List<Sale> exportSales(LocalDate from, LocalDate to) {

        return mongoDBSaleReposository.findByRegisterDateBetween(from, to);
    }
}
