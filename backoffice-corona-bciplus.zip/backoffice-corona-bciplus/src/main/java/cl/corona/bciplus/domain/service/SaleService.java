package cl.corona.bciplus.domain.service;


import cl.corona.bciplus.application.inbound.SaleInboundPort;
import cl.corona.bciplus.application.outbound.SaleOutboundPort;
import cl.corona.bciplus.domain.data.SalePaginationDTO;
import cl.corona.bciplus.domain.data.SaleResponseDTO;
import cl.corona.bciplus.domain.ex.BadRequestException;
import cl.corona.bciplus.domain.ex.NoContentException;
import cl.corona.bciplus.domain.util.DateValidation;
import cl.corona.bciplus.infrastructure.db.entity.Sale;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SaleService implements SaleInboundPort {

    @Autowired
    private SaleOutboundPort saleOutboundPort;

    private static final String SHEET = "Ventas";

    private static final String[] COLUMN_HEADERS = {"Código", "Campaña", "Fecha de registro", "Número de orden", "URL Confirmación", "TOTAL", "Comisión por venta"};

    @Value("${sale.comission}")
    private double salesComission;

    @Value("${iva}")
    private double iva;

    private static final int INCREMENT_ROW = 1;

    private static final long PLUS_DAY = 1;

    private static final int POSITION_TITLE_TOTALS = 0;
    private static final int POSITION_VALUE_TOTALS = 6;

    @Autowired
    private DateValidation dateValidation;

    @Override
    public SalePaginationDTO getSales(int page, int size, LocalDate from, LocalDate to) {
        if (size <= 0) {
            log.error("Error con cantidad de items por pagina");
            throw new BadRequestException("Cantidad de items debe ser mayor o igual a 1");
        }
        if (page < 0) {
            log.error("Error con numero de pagina");
            throw new BadRequestException("Numero de página debe ser mayor o igual a 0");
        }
        dateValidation.dateValidate(from, to);
        to = to.plusDays(PLUS_DAY);
        Page<Sale> body = saleOutboundPort.getSales(page, size, from, to);

        log.debug("Cantidad de registros: {}", body.getTotalElements());

        SalePaginationDTO salePaginationDTO = new SalePaginationDTO();
        salePaginationDTO.setActualPage(body.getNumber());
        salePaginationDTO.setTotalElements(body.getTotalElements());
        salePaginationDTO.setTotalPages(body.getTotalPages());
        salePaginationDTO.setSales(body.stream().map(b -> {
            Map mapBody = b.getBody();

            ObjectMapper mapper = new ObjectMapper();
            SaleResponseDTO response = null;
            try {
                response = mapper.convertValue(mapBody, SaleResponseDTO.class);

                response.getSale().setComission(getComission(response.getSale().getSubtotal()));
            } catch (Exception e) {
                log.error("Se produjo un error al mapear resultado de ventas: {} ", e.getMessage());
            }

            response.setRegisterDate(b.getRegisterDate());

            return response;
        }).collect(Collectors.toList()));

        return salePaginationDTO;
    }

    public int getComission(int subTotal) {
        return (int) Math.round(subTotal * salesComission);
    }


    @Override
    public ByteArrayInputStream exportSales(LocalDate from, LocalDate to) {
        dateValidation.dateValidate(from, to);

        to = to.plusDays(PLUS_DAY);


        List<Sale> sales = saleOutboundPort.exportSales(from, to);

        if (sales == null || sales.isEmpty()) {
            log.error("No existen registros para la fecha indicada");
            throw new NoContentException();
        }

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet(SHEET);

            CellStyle cellStyle = workbook.createCellStyle();
            Font font = workbook.createFont();

            // Header
            Row headerRow = sheet.createRow(0);
            for (int col = 0; col < COLUMN_HEADERS.length; col++) {

                Cell cell = headerRow.createCell(col);
                cellStyle.setAlignment(HorizontalAlignment.CENTER);
                cell.setCellStyle(cellStyle);
                font.setBold(true);
                cellStyle.setFont(font);
                cell.setCellValue(COLUMN_HEADERS[col]);

            }
            AtomicInteger rowIdx = new AtomicInteger(1);

            log.debug("Comision de venta: {} %", salesComission);

            AtomicInteger totalNetoComission = new AtomicInteger();

            sales.stream().forEach(s -> {
                Map mapBody = s.getBody();
                ObjectMapper mapper = new ObjectMapper();
                SaleResponseDTO response = mapper.convertValue(mapBody, SaleResponseDTO.class);
                log.debug("CODE: {}", response.getCode());
                log.debug("CAMPAIGN: {}", response.getCampaign());
                Row row = sheet.createRow(rowIdx.getAndIncrement());
                row.createCell(0).setCellValue(response.getCode());
                row.createCell(1).setCellValue(response.getCampaign());
                LocalDateTime registerDate = s.getRegisterDate();
                String formatDate = registerDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
                row.createCell(2).setCellValue(formatDate);
                row.createCell(3).setCellValue(response.getSale().getOrderNumber());
                row.createCell(4).setCellValue(response.getSale().getSuccessUrl());
                row.createCell(5).setCellValue(response.getSale().getSubtotal());


                int calculatedComission = getComission(response.getSale().getSubtotal());
                //comission aproximada
                log.debug("Venta: {}", response.getSale().getSubtotal());
                log.debug("Comision calculada por venta: {}", calculatedComission);
                row.createCell(6).setCellValue(calculatedComission);
                totalNetoComission.set(totalNetoComission.get() + calculatedComission);

            });

            log.debug("----------------");
            CellStyle totalCellStyle = workbook.createCellStyle();
            totalCellStyle.setAlignment(HorizontalAlignment.LEFT);
            font.setBold(true);
            totalCellStyle.setFont(font);
            int idx = rowIdx.getAndIncrement() + INCREMENT_ROW;
            Row rowNeto = totalRowGenerate(idx, sheet, totalCellStyle, "Total Neto", totalNetoComission.get());
            log.debug("Total comision neta: {}", totalNetoComission.get());

            idx = idx + INCREMENT_ROW;
            Row rowIVA = totalRowGenerate(idx, sheet, totalCellStyle, "Total IVA", (int) Math.round(totalNetoComission.get() * iva));
            log.debug("Total IVA: {}", (int) Math.round(totalNetoComission.get() * iva));

            idx = idx + INCREMENT_ROW;
            Row rowTotalComission = totalRowGenerate(idx, sheet, totalCellStyle, "Total Comisión", (int) Math.round((totalNetoComission.get() * iva) + totalNetoComission.get()));
            log.debug("Total Comision: {}", (int) Math.round((totalNetoComission.get() * iva) + totalNetoComission.get()));
            autoSizeColumn(sheet);
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("Se produjo un error al generar archivo a exportar {}", e.getMessage());
            throw new BadRequestException("Se produjo un error al generar archivo a exportar");
        }
    }

    private Row totalRowGenerate(int idx, Sheet sheet, CellStyle totalCellStyle, String title, int value) {
        Row row = sheet.createRow(idx);
        row.createCell(POSITION_TITLE_TOTALS).setCellValue(title);
        row.createCell(POSITION_VALUE_TOTALS).setCellValue(value);
        row.getCell(POSITION_TITLE_TOTALS).setCellStyle(totalCellStyle);
        row.getCell(POSITION_VALUE_TOTALS).setCellStyle(totalCellStyle);

        return row;
    }

    private void autoSizeColumn(Sheet sheet) {
        for (int col = 0; col < COLUMN_HEADERS.length; col++) {
            sheet.autoSizeColumn(col);
        }
    }
}
