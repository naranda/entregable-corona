package cl.corona.bciplus.application.outbound;

import cl.corona.bciplus.infrastructure.db.entity.LogError;
import org.springframework.data.domain.Page;

import java.time.LocalDate;
import java.util.List;

public interface LogErrorOutboundPort {
    List<LogError> exportLogError(LocalDate from, LocalDate to);

    Page<LogError> getLogErrors(int page, int size, LocalDate from, LocalDate to);
}
