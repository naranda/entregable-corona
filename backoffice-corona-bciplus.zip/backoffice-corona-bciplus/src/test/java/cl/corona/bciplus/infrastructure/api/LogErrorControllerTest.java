package cl.corona.bciplus.infrastructure.api;

import cl.corona.bciplus.application.inbound.LogErrorInboundPort;
import cl.corona.bciplus.domain.data.LogErrorPaginationDTO;
import cl.corona.bciplus.domain.data.LogErrorResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(LogErrorController.class)
class LogErrorControllerTest {

    @MockBean
    private LogErrorInboundPort logErrorInboundPort;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getLogErrorTest_status200() throws Exception {

        var response = getLogErrorResponse();

        when(logErrorInboundPort.getLogErrors(anyInt(), anyInt(), any(), any())).thenReturn(response);

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/log?page=0&size=10&from=01-10-2022&to=08-11-2022")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void getLogErrorsWithOutFromTest_status400() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/log?page=0&size=10&to=08-11-2022")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    @Test
    void getLogErrorsWithOutToTest_status400() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/log?page=0&size=10&from=08-11-2022")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }


    private LogErrorPaginationDTO getLogErrorResponse() {
        var response = new LogErrorPaginationDTO();
        response.setActualPage(0);
        response.setTotalElements(1);
        response.setTotalPages(1);

        LogErrorResponseDTO logErrorResponseDTO = new LogErrorResponseDTO();
        logErrorResponseDTO.setRegisterDate(LocalDateTime.now());
        logErrorResponseDTO.setError("error venta");
        logErrorResponseDTO.setMessage("Error en procesar la venta de polera de mujer");
        logErrorResponseDTO.setStore("www.corona.cl");
        logErrorResponseDTO.setLeadCode("HDU-PDF-XLS");


        return response;
    }
}
