package cl.corona.bciplus.domain.service;

import cl.corona.bciplus.application.outbound.SaleOutboundPort;
import cl.corona.bciplus.domain.ex.BadRequestException;
import cl.corona.bciplus.domain.ex.NoContentException;
import cl.corona.bciplus.domain.util.DateValidation;
import cl.corona.bciplus.infrastructure.db.entity.Sale;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SaleServiceTest {

    @Mock
    private SaleOutboundPort saleOutboundPort;

    @Mock
    private DateValidation dateValidation;

    @InjectMocks
    private SaleService saleService;

    private static final long PLUS_DAY = 1;


    @Test
    void getSalesOkTest() throws JsonProcessingException {

        int page = 0;
        int size = 10;
        LocalDate now = LocalDate.now();
        LocalDate from = now;
        from = from.minusDays(10);
        LocalDate to = now;


        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        Sale sale = getSale();
        List<Sale> list = Arrays.asList(sale);
        Page<Sale> result = new PageImpl(list);

        when(saleOutboundPort.getSales(page, size, from, toPlusDay)).thenReturn(result);

        saleService.getSales(page, size, from, to);

    }

    @Test
    void exportSalesNoContentNullTest() {

        LocalDate now = LocalDate.now();
        LocalDate from = now.minusDays(10);

        LocalDate to = now;

        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        when(saleOutboundPort.exportSales(from, toPlusDay)).thenReturn(null);

        assertThatExceptionOfType(NoContentException.class)
                .isThrownBy(() -> saleService.exportSales(from, to))
                .withNoCause();

    }

    @Test
    void exportSalesNoContentEmptyTest() {

        LocalDate now = LocalDate.now();
        LocalDate from = now.minusDays(10);

        LocalDate to = now;

        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        List<Sale> list = new ArrayList<>();

        when(saleOutboundPort.exportSales(from, toPlusDay)).thenReturn(list);

        assertThatExceptionOfType(NoContentException.class)
                .isThrownBy(() -> saleService.exportSales(from, to))
                .withNoCause();

    }

    @Test
    void getSalesFromDateErrorTest() throws JsonProcessingException {

        int page = 0;
        int size = 10;
        LocalDate to = LocalDate.now();
        LocalDate from = to.plusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.getSales(page, size, from, to))
                .withNoCause();
    }

    @Test
    void getSalesToDateErrorTest() throws JsonProcessingException {

        int page = 0;
        int size = 10;
        LocalDate now = LocalDate.now();
        LocalDate from = now;
        LocalDate to = now.plusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.getSales(page, size, from, to))
                .withNoCause();
    }

    @Test
    void getSalesFromMajorToDateErrorTest() throws JsonProcessingException {

        int page = 0;
        int size = 10;
        LocalDate now = LocalDate.now().minusDays(20);
        LocalDate from = now;
        LocalDate to = now.minusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.getSales(page, size, from, to))
                .withNoCause();
    }

    @Test
    void getSalesNullDatesErrorTest() throws JsonProcessingException {

        int page = 0;
        int size = 10;

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(null, null);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.getSales(page, size, null, null))
                .withNoCause();
    }

    @Test
    void exportSaleTest() throws JsonProcessingException {
        LocalDate to = LocalDate.now();
        LocalDate from = to;
        from = from.minusDays(10);
        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        List<Sale> sales = Arrays.asList(getSale());
        when(saleOutboundPort.exportSales(from, toPlusDay)).thenReturn(sales);
        saleService.exportSales(from, to);
    }

    @Test
    void exportSaleFromDateErrorTest() throws JsonProcessingException {
        LocalDate now = LocalDate.now();
        LocalDate from = now.plusDays(10);
        LocalDate to = now;

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.exportSales(from, to))
                .withNoCause();
    }

    @Test
    void exportSalesToDateErrorTest() throws JsonProcessingException {

        LocalDate now = LocalDate.now();
        LocalDate from = now;
        LocalDate to = now.plusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.exportSales(from, to))
                .withNoCause();
    }

    @Test
    void exportSalesFromMajorToDateErrorTest() throws JsonProcessingException {

        LocalDate now = LocalDate.now().minusDays(20);
        LocalDate from = now;
        LocalDate to = now.minusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.exportSales(from, to))
                .withNoCause();
    }

    @Test
    void exportSalesNullDatesErrorTest() throws JsonProcessingException {
        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(null, null);
        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> saleService.exportSales(null, null))
                .withNoCause();
    }

    private Sale getSale() throws JsonProcessingException {
        var result = new Sale();

        String body = "{\"campaign\":\"6241d686423a11001cbbc133\",\"code\":\"056G-JY59-2DCDH1\",\"sale\":{\"orderNumber\":\"Pedido R367790352 | CORONA\",\"subtotal\":3199,\"items\":[{\"title\":\"Polera mujer\",\"quantity\":1,\"totalPrice\":3199}],\"successUrl\":\"https://www.corona.cl/orders/R367790352\"}}";

        ObjectMapper mapper = new ObjectMapper();
        Map<Object, Object> map = mapper.readValue(body, Map.class);

        result.setBody(map);
        result.setRegisterDate(LocalDateTime.now());

        return result;
    }

}
