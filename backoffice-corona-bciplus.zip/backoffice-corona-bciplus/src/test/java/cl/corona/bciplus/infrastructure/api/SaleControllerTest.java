package cl.corona.bciplus.infrastructure.api;

import cl.corona.bciplus.application.inbound.SaleInboundPort;
import cl.corona.bciplus.domain.data.ItemDTO;
import cl.corona.bciplus.domain.data.SaleDTO;
import cl.corona.bciplus.domain.data.SalePaginationDTO;
import cl.corona.bciplus.domain.data.SaleResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDateTime;
import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(SaleController.class)
class SaleControllerTest {

    @MockBean
    private SaleInboundPort saleInboundPort;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getSalesTest_status200() throws Exception {

        var response = getSalesResponse();

        when(saleInboundPort.getSales(anyInt(), anyInt(), any(), any())).thenReturn(response);

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/sales?page=0&size=10&from=01-10-2022&to=08-11-2022")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void getSalesWithOutFromTest_status400() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/sales?page=0&size=10&to=08-11-2022")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    @Test
    void getSalesWithOutToTest_status400() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/sales?page=0&size=10&from=08-11-2022")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }


    private SalePaginationDTO getSalesResponse() {
        var response = new SalePaginationDTO();
        response.setActualPage(0);
        response.setTotalElements(1);
        response.setTotalPages(1);

        SaleResponseDTO saleResponseDTO = new SaleResponseDTO();
        saleResponseDTO.setRegisterDate(LocalDateTime.now());
        saleResponseDTO.setCode("056G-JY59-2DCD");
        saleResponseDTO.setCampaign("6241d686423a11001cbbc133");


        SaleDTO saleDTO = new SaleDTO();
        saleDTO.setComission(160);
        saleDTO.setSubtotal(3199);
        saleDTO.setSuccessUrl("https://www.corona.cl/orders/R367790352");
        saleDTO.setOrderNumber("Pedido R367790352 | CORONA");

        ItemDTO itemDTO = new ItemDTO();
        itemDTO.setQuantity(1);
        itemDTO.setTitle("Polera mujer");
        itemDTO.setTotalPrice(3199);

        saleDTO.setItems(Arrays.asList(itemDTO));

        saleResponseDTO.setSale(saleDTO);

        return response;
    }
}
