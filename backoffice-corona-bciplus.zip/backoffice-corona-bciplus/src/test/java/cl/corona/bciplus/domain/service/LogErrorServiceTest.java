package cl.corona.bciplus.domain.service;

import cl.corona.bciplus.application.outbound.LogErrorOutboundPort;
import cl.corona.bciplus.domain.ex.BadRequestException;
import cl.corona.bciplus.domain.ex.NoContentException;
import cl.corona.bciplus.domain.util.DateValidation;
import cl.corona.bciplus.infrastructure.db.entity.LogError;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LogErrorServiceTest {

    @Mock
    private LogErrorOutboundPort logErrorOutboundPort;

    @Mock
    private DateValidation dateValidation;

    @InjectMocks
    private LogErrorService logErrorService;

    private static final long PLUS_DAY = 1;


    @Test
    void exportLogErrorNoContentNullTest() {

        LocalDate now = LocalDate.now();
        LocalDate from = now.minusDays(10);

        LocalDate to = now;

        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        when(logErrorOutboundPort.exportLogError(from, toPlusDay)).thenReturn(null);

        assertThatExceptionOfType(NoContentException.class)
                .isThrownBy(() -> logErrorService.exportLogError(from, to))
                .withNoCause();

    }

    @Test
    void exportLogErrorNoContentEmptyTest() {

        LocalDate now = LocalDate.now();
        LocalDate from = now.minusDays(10);

        LocalDate to = now;

        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        List<LogError> list = new ArrayList<>();

        when(logErrorOutboundPort.exportLogError(from, toPlusDay)).thenReturn(list);

        assertThatExceptionOfType(NoContentException.class)
                .isThrownBy(() -> logErrorService.exportLogError(from, to))
                .withNoCause();

    }

    @Test
    void exportLogErrorTest() throws JsonProcessingException {
        LocalDate to = LocalDate.now();
        LocalDate from = to;
        from = from.minusDays(10);
        LocalDate toPlusDay = to.plusDays(PLUS_DAY);

        List<LogError> errors = Arrays.asList(getErrors());
        when(logErrorOutboundPort.exportLogError(from, toPlusDay)).thenReturn(errors);
        logErrorService.exportLogError(from, to);
    }

    @Test
    void exportLogErrorFromDateErrorTest() throws JsonProcessingException {
        LocalDate now = LocalDate.now();
        LocalDate from = now.plusDays(10);
        LocalDate to = now;

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> logErrorService.exportLogError(from, to))
                .withNoCause();
    }

    @Test
    void exportSalesToDateErrorTest() throws JsonProcessingException {

        LocalDate now = LocalDate.now();
        LocalDate from = now;
        LocalDate to = now.plusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> logErrorService.exportLogError(from, to))
                .withNoCause();
    }

    @Test
    void exportSalesFromMajorToDateErrorTest() throws JsonProcessingException {

        LocalDate now = LocalDate.now().minusDays(20);
        LocalDate from = now;
        LocalDate to = now.minusDays(10);

        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(from, to);

        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> logErrorService.exportLogError(from, to))
                .withNoCause();
    }

    @Test
    void exportSalesNullDatesErrorTest() throws JsonProcessingException {
        doThrow(BadRequestException.class).doNothing().when(dateValidation).dateValidate(null, null);
        assertThatExceptionOfType(BadRequestException.class)
                .isThrownBy(() -> logErrorService.exportLogError(null, null))
                .withNoCause();
    }

    private LogError getErrors() throws JsonProcessingException {
        var result = new LogError();

        String body = "{\"store\":\"www.corona.cl\",\"leadCode\":\"056G-JY59-2DCDH1\",\"error\":\"Error Venta\", \"message\":\"Error en procesar la venta de polera de mujer\"}";

        ObjectMapper mapper = new ObjectMapper();
        Map<Object, Object> map = mapper.readValue(body, Map.class);

        result.setBody(map);
        result.setRegisterDate(LocalDateTime.now());

        return result;
    }

}
