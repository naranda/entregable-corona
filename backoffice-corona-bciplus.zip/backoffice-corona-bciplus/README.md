# Información del proyecto Backoffice Corona - BCI Plus
___________________
___________________
### Resumen 
API Rest backoffice para uso interno de CORONA. Servicios que listan las ventas realizadas en campaña CORONA - BCI Plus y generación de reportería.

### Stack Tecnológico
- Java 11
- Spring Boot 2.7.5
- MongoDB 6.0.2 Community
- POI 5.2.0
- Maven 3.8.6

### Microservicio Backoffice CORONA - BCI Plus.

A continuación se indican los pasos para verificación de servicio en ambiente local usando Docker.

### Compilar y generar package

``$ mvn clean package -DskipTests``

### Generación contenedor Docker

``$ docker build --no-cache --build-arg JAR_FILE=./target/backoffice-corona-bciplus-1.0.jar -t backoffice-corona-bciplus:latest .``


### Ejecutar Docker

``$ docker run -p 8080:8080 backoffice-corona-bciplus``

### Comprobación Local

``http://localhost:8080/backoffice-corona-bciplus/api/swagger-ui.html``

### Servicios Rest

#### 1 Listar ventas realizadas en un rango de fechas

    URI: http://localhost:8080/backoffice-corona-bciplus/api/sales

    TIPO: GET

    Parámetros: 

        page: Número de página a mostrar (paginacion), opcional, por defecto 0
        size: Cantidad de items por página, opcional por defecto 10
        from: Rango de fecha desde, formato dd-MM-yyyy, obligatorio
        to: Rango de fecha hasta, formato dd-MM-yyyy, obligatorio

    Ejemplo:

    http://localhost:8080/backoffice-corona-bciplus/api/sales?page=0&size=15&from=01-10-2022&to=07-11-2022

    Respuesta: Formato JSON

    {
        "totalPages": 1,
        "actualPage": 0,
        "totalElements": 2,
        "sales": [
            {
                "registerDate": "04-11-2022 12:07:28",
                "campaign": "6241d686423a11001cbbc133",
                "code": "056G-JY59-2DCD",
                "sale": {
                    "orderNumber": "Pedido R367790352 | CORONA",
                    "items": [
                        {
                            "title": "Polera mujer",
                            "quantity": 1,
                            "totalPrice": 3199
                        }
                    ],
                    "subtotal": 3199,
                    "comission": 160,
                    "successUrl": "https://www.corona.cl/orders/R367790352"
                }
            },
            {
                "registerDate": "04-11-2022 12:25:38",
                "campaign": "6241d686423a11001cbbc133",
                "code": "2DTB-39FE-8Q8V",
                "sale": {
                    "orderNumber": "Pedido R640946155 | CORONA",
                    "items": [
                        {
                            "title": "Pantalon mujer",
                            "quantity": 1,
                            "totalPrice": 6699
                        }
                    ],
                    "subtotal": 6699,
                    "comission": 335,
                    "successUrl": "https://www.corona.cl/orders/R640946155"
                }
            }
            ]
    }

**NOTA**: Estructura JSON de respuesta puede variar según definición al momento de registrar la venta. 
    
#### 2 Exportar ventas realizadas en un rango de fechas

    URI: http://localhost:8080/backoffice-corona-bciplus/api/sales/export

    TIPO: GET

    Parámetros:

        from: Rango de fecha desde, formato dd-MM-yyyy, obligatorio
        to: Rango de fecha hasta, formato dd-MM-yyyy, obbligatorio

    Ejemplo:

    http://localhost:8080/backoffice-corona-bciplus/api/sales/export?from=01-10-2022&to=07-11-2022

    Respuesta: Archivo excel

#### 3 Listar log de errores en un rango de fechas

    URI: http://localhost:8080/backoffice-corona-bciplus/api/log

    TIPO: GET

    Parámetros: 

        page: Número de página a mostrar (paginacion), opcional, por defecto 0
        size: Cantidad de items por página, opcional por defecto 10
        from: Rango de fecha desde, formato dd-MM-yyyy, obligatorio
        to: Rango de fecha hasta, formato dd-MM-yyyy, obligatorio

    Ejemplo:

    http://localhost:8080/backoffice-corona-bciplus/api/log?page=0&size=15&from=01-10-2022&to=07-11-2022

    Respuesta: Formato JSON

    {
        "totalPages": 1,
        "actualPage": 0,
        "totalElements": 1,
        "logErrors": [
        {
            "registerDate": "14-11-2022 16:45:55",
            "store": "www.corona.cl",
            "leadCode": "HDU-PDF-XLS",
            "error": "error venta",
            "message": "Error en procesar la venta de polera de mujer"
        }
        ]
    }

**NOTA**: Estructura JSON de respuesta puede variar seguún definición al momento de registrar el log de error.

#### 4 Exportar log de errores en un rango de fechas

    URI: http://localhost:8080/backoffice-corona-bciplus/api/log/export

    TIPO: GET

    Parámetros:

        from: Rango de fecha desde, formato dd-MM-yyyy, obligatorio
        to: Rango de fecha hasta, formato dd-MM-yyyy, obligatorio

    Ejemplo:

    http://localhost:8080/backoffice-corona-bciplus/api/log/export?from=01-10-2022&to=07-11-2022

    Respuesta: Archivo excel